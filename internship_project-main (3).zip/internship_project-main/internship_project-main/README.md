# internship_project
This repository contains the internship project along with dataset required.
The project is to build a Restaurant predictor app based on the Cuisine, location & price.
